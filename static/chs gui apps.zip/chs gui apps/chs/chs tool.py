import tkinter as tk

window = tk.Tk()

label = tk.Label(window, text="Hello, Tkinter!",foreground="red",background="light gray",width=10,height=10)

label.pack()



window.mainloop()
